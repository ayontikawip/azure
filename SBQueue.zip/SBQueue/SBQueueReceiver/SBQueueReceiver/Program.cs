﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.ServiceBus.Messaging;

namespace SBQueueReceiver
{
    class Program
    {
        static string ConnectionString = "Endpoint=sb://puneservbus532.servicebus.windows.net/;SharedAccessKeyName=policy1;SharedAccessKey=un1/sPBA65Xl+JA9TSFz+Is012xXxo1cDooZgik2O8I=;EntityPath=queue1";
        static string QueuePath = "";

        static void Main(string[] args)
        {
            //Service Bus Queue Receiver
            var queueClient = QueueClient.CreateFromConnectionString(ConnectionString);

            queueClient.OnMessage(msg => ProcessMessage(msg));

            Console.WriteLine("Press Enter to Exit...");
            Console.ReadLine();

            queueClient.Close();
        }

        private static void ProcessMessage(BrokeredMessage msg)
        {
            var text = msg.GetBody<string>();
            Console.WriteLine("\nReceived Messages : " + text);
        }

    }
}

