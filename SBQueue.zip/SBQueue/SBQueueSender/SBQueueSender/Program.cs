﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.ServiceBus.Messaging;


namespace SBQueueSender
{
    class Program
    {
        static string ConnectionString = "Endpoint=sb://puneservbus532.servicebus.windows.net/;SharedAccessKeyName=policy1;SharedAccessKey=un1/sPBA65Xl+JA9TSFz+Is012xXxo1cDooZgik2O8I=;EntityPath=queue1";
        static string QueuePath = "";

        static void Main(string[] args)
        {
            //Service Bus Queue Sender
            var queueClient = QueueClient.CreateFromConnectionString(ConnectionString);
         //s   var queueClient = QueueClient.CreateFromConnectionString(ConnectionString, QueuePath);
            for (int i = 0; i < 10; i++)
            {
                var message = new BrokeredMessage("Sender's Message ==> " + i);
                queueClient.Send(message);
                Console.Write("\nSent Message : = " + i);
            }

            Console.WriteLine("Press Enter to Exit...");
            Console.ReadLine();
            queueClient.Close();

        }
    }
}
